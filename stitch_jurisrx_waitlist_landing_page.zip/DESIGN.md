---
name: JurisRx Authority
colors:
  surface: '#131316'
  surface-dim: '#131316'
  surface-bright: '#39393c'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1e'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e5'
  on-surface-variant: '#bccac2'
  inverse-surface: '#e5e1e5'
  inverse-on-surface: '#313033'
  outline: '#87948d'
  outline-variant: '#3d4944'
  surface-tint: '#6bdab5'
  primary: '#80f0c9'
  on-primary: '#003829'
  primary-container: '#63d3ae'
  on-primary-container: '#005944'
  inverse-primary: '#006c52'
  secondary: '#cebdff'
  on-secondary: '#381385'
  secondary-container: '#4f319c'
  on-secondary-container: '#bea8ff'
  tertiary: '#ffd2ba'
  on-tertiary: '#532200'
  tertiary-container: '#ffac7c'
  on-tertiary-container: '#7b3c11'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#88f7d0'
  primary-fixed-dim: '#6bdab5'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#00513d'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cebdff'
  on-secondary-fixed: '#21005e'
  on-secondary-fixed-variant: '#4f319c'
  tertiary-fixed: '#ffdbc9'
  tertiary-fixed-dim: '#ffb68d'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#73350a'
  background: '#131316'
  on-background: '#e5e1e5'
  surface-variant: '#353437'
typography:
  display-lg:
    fontFamily: DM Serif Display
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: DM Serif Display
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-md:
    fontFamily: DM Serif Display
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-sm:
    fontFamily: DM Serif Display
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  body-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-label:
    fontFamily: DM Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  data-value:
    fontFamily: DM Mono
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

The design system establishes an authoritative, high-credibility environment tailored for pharmacy law candidates. The brand personality is scholarly yet technologically advanced, blending the traditional gravity of legal study with the efficiency of modern EdTech. 

The aesthetic is a sophisticated **Modern-Corporate** hybrid with **Minimalist** influences. It prioritizes information density and focus by utilizing a deep obsidian foundation, allowing vibrant accents to guide the user's attention to critical legal nuances. The emotional response is one of calm confidence, precision, and academic rigor. All blue tones are strictly excluded to differentiate the product from generic medical software and to reduce eye strain during late-night study sessions.

## Colors

The palette is optimized for high-contrast legibility against a near-black background.

*   **Primary (Accent Green):** Used for "Success" states, primary actions, and progress indicators. It represents the "Go" signal of passing an exam.
*   **Secondary (Purple):** Reserved for legislative links, legal citations, and secondary navigational elements.
*   **Tertiary (Amber):** Critical for warnings, "caution" notes in law, and flagging questions for review.
*   **Neutrals:** The background is a deep `#060608`. Surfaces and containers use a slightly elevated `#121217` to create subtle depth without relying on heavy shadows.

## Typography

The typography strategy employs a triple-font system to categorize information types:
1.  **Serif (Headlines):** Used for section titles and major legal headings to evoke a sense of traditional law and formal publication.
2.  **Sans (Body):** Used for all explanatory text and question stems to ensure maximum readability and reduced cognitive load.
3.  **Mono (Data/Labels):** Used for technical data, statute numbers, exam timers, and meta-tags. This provides a "technical" feel, suggesting precision and data-driven accuracy.

## Layout & Spacing

This design system utilizes a **Fixed Grid** on desktop and a **Fluid Grid** on mobile. 
*   **Desktop:** 12-column grid with a 1280px max-width. Gutters are fixed at 24px to provide significant breathing room between dense legal blocks.
*   **Mobile:** 4-column fluid grid with 16px margins. 
*   **Vertical Rhythm:** Spacing follows a 4px/8px baseline. Use `lg` (48px) for separating major content sections and `sm` (16px) for internal card padding.

## Elevation & Depth

Depth is achieved through **Tonal Layers** rather than traditional shadows, maintaining a crisp, high-contrast look.
*   **Level 0 (Background):** `#060608` - The base canvas.
*   **Level 1 (Cards/Surface):** `#121217` - Primary container for content. Features a 1px stroke of `#ffffff` at 10% opacity for definition.
*   **Level 2 (Modals/Overlays):** `#1c1c24` - Highest elevation.
*   **Interactions:** Hover states on cards should increase the border-opacity to 30% rather than adding a shadow, preserving the "flat but deep" aesthetic.

## Shapes

The shape language balances the rigidness of law with the friendliness of modern software.
*   **Cards & Modals:** Use a `12px` (rounded-lg) corner radius to soften the interface.
*   **Input Fields & Buttons:** Use a `8px` (standard) radius.
*   **Selection Chips:** Use "Pill" (full radius) for status tags (e.g., "Federal", "State-Specific").

## Components

*   **Buttons:** Primary buttons use a solid Accent Green background with dark text. Secondary buttons use an outline of Secondary Purple with Purple text. No blue gradients.
*   **Cards:** Background `#121217`, 12px border-radius, 1px subtle stroke. Header titles within cards use the Serif font.
*   **Inputs:** High-contrast dark backgrounds (`#0a0a0f`) with a focus state of 2px Accent Green border. Error states use Amber.
*   **Data Points:** Statute IDs, timestamps, and scores must be rendered in DM Mono. Use a subtle background fill (e.g., Purple at 10% opacity) for statute tags.
*   **Progress Bars:** Thin, 4px height tracks. Completed segments use Accent Green; "In Review" segments use Amber.
*   **Selection States:** Radio buttons and checkboxes use the Accent Green for "Selected" states, ensuring they pop against the dark background.